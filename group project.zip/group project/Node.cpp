#include "Node.h"

Node::Node(const Student &data) : data(data), next(nullptr) {}