#include "Person.h"
Person::Person(const std::string &name, int id) : name(name), id(id) {}
Person::~Person() {}
