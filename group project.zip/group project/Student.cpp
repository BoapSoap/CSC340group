#include "Student.h"
#include "Person.h"
#include <iostream>

Student::Student(const std::string &name, int id, const std::string &major)
    : Person(name, id), major(major) {}

std::string Student::getMajor() const {
    return major;
}

void Student::displayInfo() const {
    std::cout << "Name: " << getName() << ", ID: " << getId() 
              << ", Major: " << major << '\n';
}