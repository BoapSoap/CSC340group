#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include "Student.h"
#include <string>

class LinkedList {
private:
    struct Node {
        Student data;
        Node* next;
        Node(const Student &data) : data(data), next(nullptr) {}
    };
    Node* head;

public:
    LinkedList();
    ~LinkedList();
    void add(const Student &student);
    void displayAll() const;
    void searchByMajor(const std::string &major) const;
    void sortByName();

private:
    static bool compareStudentsByName(const Student &a, const Student &b);
};
#endif