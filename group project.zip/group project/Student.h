#ifndef STUDENT_H
#define STUDENT_H
#include "Person.h"
#include <string>

class Student : public Person {
private:
    std::string major;
public:
    Student(const std::string &name = "", int id = 0, const std::string &major = "");
    virtual ~Student() {}
    std::string getMajor() const;
    virtual void displayInfo() const;
};
#endif